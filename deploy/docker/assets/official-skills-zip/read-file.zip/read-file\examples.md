# 读取文件使用示例

本文档提供 read_file 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：读取 JSON 配置文件用于应用初始化

**场景**：应用启动时需要读取 backend/config/app_settings.json 中的数据库连接参数和功能开关配置。

<code>
config = read_file(file_path="backend/config/app_settings.json")
print(config)
</code>

---

## 示例 2：读取 GBK 编码的历史遗留数据文件

**场景**：数据迁移工程师需要读取 2022 年银行导出的一份 GBK 编码交易记录文件，该文件来自遗留系统。

<code>
legacy_data = read_file(file_path="data/legacy/bank_transactions_2022.txt", encoding="gbk")
print(legacy_data)
</code>

---

## 示例 3：读取 CSV 数据文件用于统计分析

**场景**：数据分析师需要读取 data/reports/sales_summary_q1.csv 中的季度销售数据，用于生成业绩报表。

<code>
import json
result = read_file(file_path="data/reports/sales_summary_q1.csv")
data = json.loads(result)
print(f"文件共 {data['lines_count']} 行，大小 {data['file_size_bytes']} 字节")
# 后续可使用 csv 模块进一步解析 data['content']
</code>

---

## 示例 4：错误处理 — 文件不存在

**场景**：用户引用的文件路径在文件系统中不存在，需要捕获错误信息以便给出友好的提示。

<code>
result = read_file(file_path="documents/report_2024.txt")
print(result)
</code>

---

## 示例 5：错误处理 — 编码错误

**场景**：应用尝试读取一个非 UTF-8 编码的文件时，需要提示用户尝试其他编码格式。

<code>
result = read_file(file_path="data/export/shift_log.txt", encoding="utf-8")
print(result)
</code>
