---
name: search-knowledge-base
allowed-tools:
  - knowledge_base_search
description: |
  提供本地知识库搜索能力。当用户需要搜索领域知识、技术文档、专家知识或本地知识库中索引的任何信息时使用此工具。支持混合搜索、精确搜索和语义搜索模式。
tags:
  - search
  - knowledge
  - local
---

# 知识库搜索工具

在本地知识库中执行搜索，使用向量相似度返回相关结果。

## 可用工具

knowledge_base_search

## knowledge_base_search参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| query | string | 是 | - | 搜索查询词 |
| index_names | array | 否 | instance.index_names | 索引名称列表 |
| search_mode | string | 否 | "hybrid" | 搜索模式 |
| rerank | boolean | 否 | False | 启用重排 |
| top_k | integer | 否 | 3 | 最大返回结果数 |

## search_mode 搜索模式可选值

| 值 | 说明 |
|------|------|
| hybrid | 语义 + 关键词搜索 |
| accurate | 关键词精确匹配 |
| semantic | 纯向量相似度 |

## 使用方式

<code>
search_result = knowledge_base_search(query="项目文档")
print(search_result)
</code>

## 返回值

knowledge_base_search返回包含搜索结果的 JSON 数组：
- `title`: 文档标题
- `text`: 文档内容
- `url`: 来源路径
- `score`: 相关性分数

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| "No knowledge base selected" | index_names 为空 | 提供有效的索引名称 |
| "No results found!" | 查询无结果 | 尝试更宽泛的查询词 |

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />
