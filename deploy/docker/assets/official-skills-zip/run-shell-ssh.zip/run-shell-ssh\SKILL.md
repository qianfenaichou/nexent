---
name: run-shell-ssh
allowed-tools:
  - terminal
description: |
  通过 SSH 连接在远程终端上执行 shell 命令。支持会话管理以在多个命令之间保持 shell 状态。使用密码认证确保连接安全。
tags:
  - ssh
  - shell
---

# 终端工具

通过 SSH 连接在远程终端上执行 shell 命令。

## 可用工具

terminal

## 参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| command | string | 是 | - | 要执行的 shell 命令 |
| session_name | string | 否 | "default" | 用于连接复用的会话名称 |
| timeout | integer | 否 | 30 | 命令超时时间（秒） |

## 使用方式

<code>
result = terminal(command="ls -la /home/user", session_name="main", timeout=30)
print(result)

result = terminal(command="pwd", session_name="main")
print(result)
</code>

## 返回值

terminal返回包含以下信息的 JSON 字符串：
- `command`: 执行的命令
- `session_name`: 使用的会话标识符
- `output`: 命令输出（已清理）
- `timestamp`: 执行时间戳

错误时：
- `command`: 执行的命令
- `session_name`: 使用的会话标识符
- `error`: 错误消息
- `timestamp`: 执行时间戳

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| Connection failed | SSH 服务器不可达 | 检查 ssh_host 和 ssh_port |
| Authentication failed | 凭据无效 | 验证 ssh_user 和 password |
| Command timeout | 命令执行超时 | 增加 timeout 值 |

## 备注

- 会话管理允许在命令之间保持状态
- 相同的 session_name 会重用现有连接
- 输出会清除 ANSI 转义序列和提示符
- 使用 Paramiko 进行密码认证

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />
