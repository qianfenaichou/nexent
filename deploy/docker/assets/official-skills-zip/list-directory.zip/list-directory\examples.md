# 列出目录使用示例

本文档提供 list_directory 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：快速查看工作区整体结构

**场景：新加入项目的开发者需要了解工作区的整体目录结构，为后续开发做准备。

<code>
result = list_directory(directory_path=".")
print(result)
</code>

---

## 示例 2：浅层查看指定目录

**场景：运营人员需要查看 data 目录下有哪些数据文件，不需要深入子目录层级。

<code>
result = list_directory(directory_path="data", max_depth=1)
print(result)
</code>

---

## 示例 3：组合参数 — 显示隐藏文件 + 显示大小 + 查询深层嵌套目录

**场景：运维工程师需要全面审查 src 目录的完整结构，包括隐藏的配置文件，并查看每个文件的大小。

<code>
result = list_directory(
    directory_path="src",
    max_depth=10,
    show_hidden=True,
    show_size=True
)
print(result)
</code>

---

## 示例 4：只查看目录结构不显示文件大小

**场景：产品经理只需要了解项目文档的目录分类结构，不需要每个文件的具体大小信息。

<code>
result = list_directory(directory_path="docs", show_size=False)
print(result)
</code>

---

## 示例 5：错误处理 — 路径指向文件而非目录

**场景：用户误将文件路径当作目录路径传入，需要工具给出清晰的类型错误提示。

<code>
result = list_directory(directory_path="config/app_settings.json")
print(result)
</code>
