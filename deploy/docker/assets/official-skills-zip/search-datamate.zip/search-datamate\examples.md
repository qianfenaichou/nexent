# DataMate 搜索工具

本文档提供 datamate_search 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：搜索指定知识库索引中的文档

**场景**：新员工入职时需要查阅"员工手册库"中的相关条款，了解请假流程的具体规定。

<code>
search_result = datamate_search(
    query="年假计算方式和请假申请流程",
    index_names=["员工手册库"]
)
print(search_result)
</code>

---

## 示例 2：调整相关性阈值获取高质量结果

**场景**：法务人员需要查找精确匹配的合同模板，不希望返回大量低相关性的参考文档。

<code>
search_result = datamate_search(
    query="软件开发技术服务合同",
    threshold=0.8
    )
print(search_result)
</code>

---

## 示例 3：组合参数 — 指定索引 + 控制结果数量 + 高阈值

**场景**：产品经理需要从"PRD文档库"中获取最相关的 3 份竞品分析报告摘要。

<code>
search_result = datamate_search(
    query="竞品功能对比分析报告",
    index_names=["PRD文档库"],
    top_k=3
)
print(search_result)
</code>

---

## 示例 4：错误处理 — 未提供索引名称

**场景**：调用 datamate_search 时没有指定 index_names 参数，导致知识库选择为空。

<code>
search_result = datamate_search(query="测试查询内容")
print(search_result)
</code>

---

## 示例 5：组合参数 — 启用 Rerank 重排 + 多索引

**场景**：技术架构师在做系统选型时，需要在"技术标准库"与"架构设计库"中搜索最相关的设计指南，并对结果进行重排优化。

<code>
search_result = datamate_search(
    query="微服务架构设计模式和最佳实践",
    index_names=["技术标准库", "架构设计库"],
    rerank=True
)
print(search_result)
</code>
