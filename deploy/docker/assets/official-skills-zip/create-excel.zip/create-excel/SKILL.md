---
name: create-excel
description: Create and generate Excel workbooks (.xlsx) from structured specifications. Use when the user wants to create an Excel workbook from scratch, generate a report with data tables, or perform focused edits such as setting cell values, adding sheets, or adjusting column widths. Supports one-shot generation and fine-grained workbook editing.
output_type: file
output_mime_types:
  - application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
---

# Excel Workbook Skill

## How This Skill Works

**The Agent does NOT execute Python directly.** Instead, it:

1. Constructs a JSON specification
2. Calls `run_skill_script()` with the spec
3. The backend executes the script in a full Python environment

```python
# CORRECT: Call the script via run_skill_script
result = run_skill_script("create-excel", "scripts/generate_xlsx.py",
    params=f"--spec '{json.dumps(spec, ensure_ascii=False)}' --output 'report.xlsx'")

# WRONG: Trying to import os, json, or using with open() in the skill context
# Those imports are NOT available in the agent execution environment
```

## TL;DR - Quick Start

**Simplest way to create a workbook (one sheet, no formulas):**

```python
spec = {
    "title": "My Report",
    "sheets": [{
        "name": "Data",
        "columns": ["Name", "Amount", "Date"],
        "data": [
            ["Apple", 100, "2026-06-01"],
            ["Banana", 200, "2026-06-02"]
        ]
    }]
}

result = run_skill_script("create-excel", "scripts/generate_xlsx.py",
    params=f"--spec '{json.dumps(spec, ensure_ascii=False)}' --output 'report.xlsx'")
```

## Input Formats

This skill supports two input formats. **Use the Simple Format for most cases.**

### Simple Format (Recommended)

Best for: Most use cases, especially when you don't need cross-sheet formulas.

```python
{
    "title": "Workbook Title",
    "sheets": [{
        "name": "Sheet Name",
        "columns": ["Col1", "Col2", "Col3"],
        "data": [[val1, val2, val3], ...],
        "date_columns": [0, 3],      # indices of columns to format as dates
        "currency_columns": [1, 2],   # indices of columns to format as currency
        "number_columns": [4],        # indices of columns to format as numbers
        "column_widths": {"A": 15, "B": 12}
    }]
}
```

**Auto-detection:**
- Dates: Columns with values like "2026-06-01" are automatically formatted
- Numbers: Numeric values are auto-detected
- Chinese column names with "金额"/"总额"/"销售额" get currency format

### Full Format (For Formulas)

Use when you need cross-sheet references or custom formulas.

```python
{
    "title": "Sales Report",
    "sheets": [
        {
            "name": "Sales",
            "tables": [{
                "header": ["Date", "Product", "Amount"],
                "data": [["2026-06-01", "Widget", 100]],
                "has_header": true,
                "start_cell": "A1"
            }],
            "cells": [
                {"cell": "D1", "value": "Total"},
                {"cell": "D2", "value": "=SUM(C2:C10)"}
            ]
        },
        {
            "name": "Summary",
            "tables": [{
                "header": ["Dept", "Total"],
                "data": [["Sales"], ["Marketing"]]
            }],
            "cells": [
                {"cell": "B2", "value": "=SUMIF(Sales!B:B,A2,Sales!C:C)"}
            ]
        }
    ]
}
```

## Common Use Cases

### Case 1: Simple Table (No Formulas)

```python
spec = {
    "title": "销售报表",
    "sheets": [{
        "name": "明细",
        "columns": ["日期", "销售员", "部门", "产品", "数量", "单价"],
        "data": [
            ["2026-06-01", "张三", "一部", "鼠标", 10, 50],
            ["2026-06-02", "李四", "二部", "键盘", 5, 120]
        ],
        "date_columns": [0],
        "column_widths": {"A": 12, "B": 10, "C": 8}
    }]
}

result = run_skill_script("create-excel", "scripts/generate_xlsx.py",
    params=f"--spec '{json.dumps(spec)}' --output 'report.xlsx'")
```

### Case 2: Table with Formula Column

Use the `cells` array to add formula columns:

```python
spec = {
    "title": "销售报表",
    "sheets": [{
        "name": "明细",
        "columns": ["产品", "数量", "单价"],
        "data": [
            ["鼠标", 10, 50],
            ["键盘", 5, 120]
        ],
        "cells": [
            {"cell": "D2", "value": "=B2*C2"},
            {"cell": "D3", "value": "=B3*C3"}
        ],
        "column_widths": {"A": 15, "B": 10, "C": 10, "D": 12}
    }]
}
```

### Case 3: Multiple Sheets with Cross-Reference

```python
spec = {
    "title": "销售汇总",
    "sheets": [
        {
            "name": "明细",
            "columns": ["部门", "产品", "销售额"],
            "data": [
                ["一部", "鼠标", 500],
                ["二部", "键盘", 600]
            ]
        },
        {
            "name": "汇总",
            "columns": ["部门", "总销售额"],
            "data": [
                ["一部"],
                ["二部"]
            ],
            "cells": [
                {"cell": "B2", "value": "=SUMIF(明细!A:A,A2,明细!C:C)"},
                {"cell": "B3", "value": "=SUMIF(明细!A:A,A3,明细!C:C)"}
            ]
        }
    ]
}
```

### Case 4: Chinese Sheet Names in Formulas

When referencing Chinese sheet names, use single quotes:

```python
"cells": [
    {"cell": "B2", "value": "=SUMIF('销售明细'!C:C,A2,'销售明细'!G:G)"}
]
```

## Return Format

```json
{
  "status": "success",
  "file_path": "report.xlsx",
  "absolute_path": "<NEXENT_WORKSPACE>/outputs/report.xlsx",
  "file_name": "report.xlsx",
  "file_size_bytes": 5120,
  "file_size_formatted": "5.0 KB",
  "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "message": "Workbook created successfully."
}
```

## Troubleshooting

### "import os is not allowed" Error

This means you're trying to execute Python code directly instead of using `run_skill_script()`.

**WRONG:**
```python
# Don't do this in skill context
import os
import json
with open("file.json", "w") as f:
    json.dump(spec, f)
```

**CORRECT:**
```python
# Just call the script
result = run_skill_script("create-excel", "scripts/generate_xlsx.py",
    params=f"--spec '{json.dumps(spec)}' --output 'report.xlsx'")
```

### JSON Escaping Issues

If you get `Invalid JSON` errors, use this pattern:

```python
# Correct: Use json.dumps with single-quoted params
params = f"--spec '{json.dumps(spec, ensure_ascii=False)}' --output 'file.xlsx'"
result = run_skill_script("create-excel", "scripts/generate_xlsx.py", params=params)

# Wrong: Nested quotes cause issues
# params = f'--spec \'{json.dumps(spec)}\' --output "file.xlsx"'  # May fail
```

### Formula Errors

- Formulas must start with `=`
- Chinese sheet names need single quotes: `='销售明细'!A1`
- Use `SUMIF`, `COUNTIF`, `VLOOKUP` for aggregation

### Date Format

Dates are auto-detected from strings like:
- `2026-06-01`
- `2026/06/01`
- `2026-06-01 10:30:00`

Format: `YYYY-MM-DD` is applied automatically.

## Script Reference

| Script | Purpose |
|--------|---------|
| `generate_xlsx.py` | One-shot workbook generation (preferred) |
| `create_workbook.py` | Create empty workbook |
| `add_sheet.py` | Add a new sheet |
| `add_table.py` | Append data table |
| `set_cell_value.py` | Set cell value |
| `set_cell_formula.py` | Set cell formula |
| `set_column_width.py` | Set column width |
| `set_row_height.py` | Set row height |
| `format_cells.py` | Apply formatting |
| `get_workbook_info.py` | Inspect structure |
| `get_workbook_path.py` | Get file path |
| `save_workbook.py` | Verify save |

## Specification Schema (Simple Format)

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Workbook/file title |
| `sheets` | array | List of sheets |
| `sheets[].name` | string | Sheet tab name |
| `sheets[].columns` | array | Column headers |
| `sheets[].data` | array | 2D data array |
| `sheets[].date_columns` | array | Column indices for date format |
| `sheets[].currency_columns` | array | Column indices for currency format |
| `sheets[].number_columns` | array | Column indices for number format |
| `sheets[].column_widths` | object | Column widths, e.g. `{"A": 15}` |

## Specification Schema (Full Format)

| Field | Type | Description |
|-------|------|-------------|
| `sheets[].tables` | array | Table definitions |
| `sheets[].tables[].header` | array | Column headers |
| `sheets[].tables[].data` | array | 2D data array |
| `sheets[].tables[].has_header` | bool | Default true |
| `sheets[].tables[].start_cell` | string | Default "A1" |
| `sheets[].tables[].column_formats` | array | Formats per column |
| `sheets[].cells` | array | Cell overrides (formulas, values) |
| `sheets[].cells[].cell` | string | Cell address, e.g. "A1" |
| `sheets[].cells[].value` | any | Cell value or formula |
| `sheets[].cells[].format` | string | Number format |

## Storage

- Default directory during an agent run: `$NEXENT_WORKSPACE/outputs`
- Standalone fallback when `NEXENT_WORKSPACE` is unset: `/mnt/nexent`
- Use `--working-dir` to change
- Keep generated files inside the current run workspace so the backend can upload and clean them up.
