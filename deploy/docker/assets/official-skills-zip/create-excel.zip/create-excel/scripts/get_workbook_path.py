#!/usr/bin/env python3
"""Get the path and metadata of an Excel workbook for frontend preview."""

import argparse
import json
import os
import sys

_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def get_workbook_path(path: str, working_dir: str = None) -> dict:
    """Get the path and metadata of an Excel workbook for frontend preview."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    if not abs_path.lower().endswith((".xlsx", ".xlsm")):
        raise ValueError(f"Not an Excel workbook: {abs_path}")

    stat = os.stat(abs_path)
    file_size = stat.st_size

    try:
        rel_path = os.path.relpath(abs_path, os.getcwd())
    except ValueError:
        rel_path = abs_path

    return {
        "status": "success",
        "file_path": rel_path,
        "absolute_path": abs_path,
        "file_name": os.path.basename(abs_path),
        "file_size_bytes": file_size,
        "file_size_formatted": _format_size(file_size),
        "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "message": f"Workbook ready for upload: {rel_path}"
    }


def _format_size(size_bytes: int) -> str:
    """Format file size in human-readable format."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def main():
    parser = argparse.ArgumentParser(description="Get Excel workbook path for preview")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = get_workbook_path(args.path, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
