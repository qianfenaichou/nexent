#!/usr/bin/env python3
"""Save (and optionally verify) an Excel workbook."""

import argparse
import json
import os
import sys

_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def save_workbook(path: str, working_dir: str = None) -> dict:
    """Save an Excel workbook and verify it exists."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    stat = os.stat(abs_path)
    file_size = stat.st_size

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "file_size_bytes": file_size,
        "message": f"Workbook saved successfully ({file_size} bytes)"
    }


def main():
    parser = argparse.ArgumentParser(description="Save and verify an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = save_workbook(args.path, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
