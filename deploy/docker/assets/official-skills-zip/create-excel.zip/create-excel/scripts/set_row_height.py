#!/usr/bin/env python3
"""Set row heights in an Excel workbook."""

import argparse
import json
import os
import re
import sys

_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def _parse_row_heights(heights_str: str) -> dict:
    """Parse row heights from JSON string or comma-separated format."""
    try:
        return json.loads(heights_str)
    except json.JSONDecodeError:
        pass

    result = {}
    for part in heights_str.split(","):
        part = part.strip()
        if not part:
            continue
        match = re.match(r'^(\d+)\s*:\s*(\d+(?:\.\d+)?)$', part)
        if match:
            result[int(match.group(1))] = float(match.group(2))
        else:
            raise ValueError(f"Invalid row format: {part}. Use '1:25' or JSON.")
    return result


def set_row_height(path: str, heights: str, sheet_index: int = 0,
                   working_dir: str = None) -> dict:
    """Set row heights in an Excel workbook.

    Args:
        path: Workbook file path
        heights: Row heights as JSON object or comma-separated string (e.g., '{"1": 25, "2": 30}' or '1:25,2:30')
        sheet_index: Sheet index to modify (default: 0)
        working_dir: Working directory (defaults to $NEXENT_WORKSPACE/outputs when available)
    """
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    row_heights = _parse_row_heights(heights)

    if not row_heights:
        raise ValueError("No row heights specified")

    wb = load_workbook(abs_path)

    if sheet_index < 0 or sheet_index >= len(wb.worksheets):
        raise ValueError(f"Sheet index {sheet_index} out of range")

    ws = wb.worksheets[sheet_index]
    applied = []

    for row_num, height in row_heights.items():
        ws.row_dimensions[int(row_num)].height = height
        applied.append({"row": int(row_num), "height": height})

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "sheet_index": sheet_index,
        "rows_updated": applied
    }


def main():
    parser = argparse.ArgumentParser(description="Set row heights in an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--heights", "-h", required=True,
                        help='Row heights as JSON or comma-separated (e.g., \'{"1": 25, "2": 30}\' or "1:25,2:30")')
    parser.add_argument("--sheet-index", "-i", type=int, default=0,
                        help="Sheet index (default: 0)")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = set_row_height(args.path, args.heights, args.sheet_index, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
