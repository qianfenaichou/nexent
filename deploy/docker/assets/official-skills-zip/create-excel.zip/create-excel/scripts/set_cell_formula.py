#!/usr/bin/env python3
"""Set a formula in a specific cell of an existing Excel workbook."""

import argparse
import json
import os
import re
import sys

_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def _col_letter_to_index(col_str):
    result = 0
    for char in col_str.upper():
        result = result * 26 + (ord(char) - ord('A') + 1)
    return result - 1


def _parse_cell(cell_str):
    match = re.match(r'^([A-Za-z]+)(\d+)$', cell_str.strip())
    if not match:
        raise ValueError(f"Invalid cell address: {cell_str}")
    col_str, row_str = match.group(1), match.group(2)
    return _col_letter_to_index(col_str), int(row_str) - 1


def set_cell_formula(path: str, cell: str, formula: str, sheet_index: int = 0,
                     working_dir: str = None) -> dict:
    """Set a formula in a specific cell of an Excel workbook.

    Args:
        path: Workbook file path
        cell: Cell address (e.g., 'A1')
        formula: Excel formula (e.g., '=SUM(A1:A10)')
        sheet_index: Sheet index (default: 0)
        working_dir: Working directory (defaults to $NEXENT_WORKSPACE/outputs when available)
    """
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    if not formula.startswith("="):
        formula = "=" + formula

    col_idx, row_idx = _parse_cell(cell)

    wb = load_workbook(abs_path)

    if sheet_index < 0 or sheet_index >= len(wb.worksheets):
        raise ValueError(f"Sheet index {sheet_index} out of range")

    ws = wb.worksheets[sheet_index]
    ws.cell(row=row_idx + 1, column=col_idx + 1, value=formula)

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "cell": cell,
        "formula": formula,
        "sheet_index": sheet_index
    }


def main():
    parser = argparse.ArgumentParser(description="Set a formula in a cell of an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--cell", "-c", required=True, help="Cell address, e.g. A1")
    parser.add_argument("--formula", "-f", required=True, help="Excel formula, e.g. =SUM(A1:A10)")
    parser.add_argument("--sheet-index", "-i", type=int, default=0,
                        help="Sheet index (default: 0)")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = set_cell_formula(args.path, args.cell, args.formula,
                                 args.sheet_index, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
