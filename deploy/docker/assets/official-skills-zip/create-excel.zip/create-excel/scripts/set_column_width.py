#!/usr/bin/env python3
"""Set column widths in an Excel workbook."""

import argparse
import json
import os
import re
import sys

_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def _col_letter_to_index(col_str):
    result = 0
    for char in col_str.upper():
        result = result * 26 + (ord(char) - ord('A') + 1)
    return result


def _parse_column_widths(widths_str: str) -> dict:
    """Parse column widths from JSON string or comma-separated format."""
    try:
        return json.loads(widths_str)
    except json.JSONDecodeError:
        pass

    result = {}
    for part in widths_str.split(","):
        part = part.strip()
        if not part:
            continue
        match = re.match(r'^([A-Za-z]+)\s*:\s*(\d+(?:\.\d+)?)$', part)
        if match:
            result[match.group(1).upper()] = float(match.group(2))
        else:
            raise ValueError(f"Invalid column format: {part}. Use 'A:15' or JSON.")
    return result


def set_column_width(path: str, widths: str, sheet_index: int = 0,
                     working_dir: str = None) -> dict:
    """Set column widths in an Excel workbook.

    Args:
        path: Workbook file path
        widths: Column widths as JSON object or comma-separated string (e.g., '{"A": 15, "B": 20}' or 'A:15,B:20')
        sheet_index: Sheet index to modify (default: 0)
        working_dir: Working directory (defaults to $NEXENT_WORKSPACE/outputs when available)
    """
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    column_widths = _parse_column_widths(widths)

    if not column_widths:
        raise ValueError("No column widths specified")

    wb = load_workbook(abs_path)

    if sheet_index < 0 or sheet_index >= len(wb.worksheets):
        raise ValueError(f"Sheet index {sheet_index} out of range")

    ws = wb.worksheets[sheet_index]
    applied = []

    for col_letter, width in column_widths.items():
        col_idx = _col_letter_to_index(col_letter)
        ws.column_dimensions[col_letter.upper()].width = width
        applied.append({"column": col_letter.upper(), "width": width})

    wb.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "sheet_index": sheet_index,
        "columns_updated": applied
    }


def main():
    parser = argparse.ArgumentParser(description="Set column widths in an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--widths", "-w", required=True,
                        help='Column widths as JSON or comma-separated (e.g., \'{"A": 15, "B": 20}\' or "A:15,B:20")')
    parser.add_argument("--sheet-index", "-i", type=int, default=0,
                        help="Sheet index (default: 0)")
    parser.add_argument("--working-dir", "-d", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = set_column_width(args.path, args.widths, args.sheet_index, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
