#!/usr/bin/env python3
"""Inspect the structure of an Excel workbook."""

import argparse
import json
import os
import sys

_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def get_workbook_info(path: str, working_dir: str = None) -> dict:
    """Inspect an Excel workbook and return its structure summary."""
    from openpyxl import load_workbook

    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Workbook not found: {abs_path}")

    wb = load_workbook(abs_path, read_only=True, data_only=True)

    sheets_info = []
    for idx, ws in enumerate(wb.worksheets):
        sheets_info.append({
            "index": idx,
            "name": ws.title,
            "max_row": ws.max_row,
            "max_column": ws.max_column
        })

    wb.close()

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "sheets_count": len(sheets_info),
        "sheets": sheets_info
    }


def main():
    parser = argparse.ArgumentParser(description="Inspect the structure of an Excel workbook")
    parser.add_argument("--path", "-p", required=True, help="Workbook file path")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = get_workbook_info(args.path, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
