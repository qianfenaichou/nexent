---
name: analyze-image
allowed-tools:
  - analyze_image
description: |
  使用视觉语言模型来理解和分析图片。支持来自 S3 URL（s3://bucket/key 或 /bucket/key）、HTTP 和 HTTPS URL 的图片。
tags:
  - visual
  - multimodal
---

# 分析图片工具

使用视觉语言模型来理解和分析图片。

## 可用方法

analyze_image

## 方法参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| image_urls_list | array | 是 | - | 图片 URL 列表（S3、HTTP 或 HTTPS） |
| query | string | 是 | - | 用于指导分析的用户问题 |

## 支持的 URL 格式

- S3: `s3://bucket/key` 或 `/bucket/key`
- HTTP: `http://example.com/image.jpg`
- HTTPS: `https://example.com/image.jpg`

## 使用方式

<code>
results = analyze_image(image_urls_list=["s3://bucket/images/photo.jpg", "https://example.com/diagram.png"], query="这些图片中显示了什么内容？")
for result in results:
    print(result)
</code>

## 返回值

返回字符串数组，每个图片按顺序返回一个分析结果：
- `results[0]`: 第一张图片的分析结果
- `results[1]`: 第二张图片的分析结果
- 以此类推

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| VLM not configured | 模型未设置 | 配置 vlm_model |
| Image download failed | URL 无效或网络问题 | 验证图片 URL |
| Analysis failed | 模型错误 | 检查 VLM 配置 |

## 备注

- 每个图片按输入顺序返回一个结果
- 支持在单个调用中处理多张图片
- 自动从 URL 下载图片

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />
