# 邮件工具调用示例

本文档提供 get_email 和 send_email 的实际应用示例，覆盖主要参数组合场景。

---

## 示例 1：获取指定时间范围内来自特定发件人的邮件

**场景**：项目经理需要查看过去两周内 boss@company.com 发来的所有邮件，以便整理周报内容。

<code>
emails = get_email(days=14, sender="boss@company.com", max_emails=20)
for email in emails:
    print(email)
</code>

---

## 示例 2：发送带 HTML 格式的会议通知邮件

**场景**：行政助理需要向全体员工发送下周一团建活动的邮件，包含活动时间、地点和报名链接。

<code>
result = send_email(
    to="all-staff@company.com",
    subject="【团建通知】4月20日周六团队建设活动",
    content="""<h2>各位同事，</h2>
<p>公司将于 <strong>4月20日（周六）</strong> 举办年度团队建设活动。</p>
<ul>
  <li><b>时间：</b>上午9:00 - 下午5:00</li>
  <li><b>地点：</b>市郊绿野庄园</li>
  <li><b>报名截止：</b>4月18日（周四）18:00</li>
</ul>
<p>点击 <a href='https://hr.company.com/team-building/register'>在线报名</a> 填写信息。</p>"""
)
print(result)
</code>

---

## 示例 3：发送邮件并添加抄送和密送

**场景**：财务人员需要向客户发送对账单，同时抄送给部门经理，并密送给审计人员。

<code>
result = send_email(
    to="client@partner.com",
    subject="2024年Q1对账单",
    content="<p>您好，请查收附件中的Q1季度对账单，如有疑问请回复此邮件。</p>",
    cc="finance-manager@company.com",
    bcc="audit@company.com"
)
print(result)
</code>

---

## 示例 4：获取邮件时组合多个筛选条件

**场景**：销售经理需要查看最近 30 天内来自所有客户域名的邮件，限制最多返回 10 封最新邮件。

<code>
emails = get_email(days=30, max_emails=10)
# 进一步按发件人域名过滤
client_emails = [e for e in emails if "@client-partner.com" in e.get("from", "")]
for email in client_emails:
    print(email)
</code>

---

## 示例 5：发送包含多个收件人的批量通知邮件

**场景**：运营团队需要在系统维护前向所有相关方发送通知邮件。

<code>
result = send_email(
    to="dev-team@company.com,qe-team@company.com,ops-team@company.com",
    subject="【重要】3月20日 02:00-04:00 系统维护通知",
    content="""<h3>尊敬的相关方，</h3>
<p>我们的系统将于 <b>3月20日凌晨 02:00 至 04:00</b> 进行例行维护。</p>
<p><b>影响范围：</b>所有在线服务暂停访问</p>
<p><b>预计恢复时间：</b>04:00</p>
<p>如有紧急情况请联系 oncall@company.com</p>"""
)
print(result)
</code>

---

## 示例 6：错误处理 — IMAP 连接失败

**场景**：用户配置的 IMAP 服务器地址错误或网络不通，导致无法拉取邮件。

<code>
emails = get_email(days=7)
print(emails)
</code>
