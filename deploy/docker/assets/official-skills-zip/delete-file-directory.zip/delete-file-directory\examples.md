# 文件与目录删除使用示例

本文档提供 delete_file 与 delete_directory 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：清理过期的临时文件

**场景**：每日凌晨的定时任务需要清理 uploads 目录下超过 30 天的临时上传文件，防止磁盘空间耗尽。

<code>
result = delete_file(path="uploads/temp/session-8821-expired.zip")
print(result)
</code>

---

## 示例 2：删除整个旧版本构建目录

**场景**：CI/CD 系统在完成新版本部署后，需要清理构建服务器上保存的旧版本构建产物，节省存储成本。

<code>
result = delete_directory(path="builds/v1.8.2")
print(result)
</code>

---

## 示例 3：删除敏感配置文件

**场景**：安全审计发现某测试环境泄露了包含明文密码的 .env.backup 文件，需要立即删除。

<code>
result = delete_file(path="config/.env.backup")
print(result)
</code>

---

## 示例 4：错误处理 — 路径不存在

**场景**：用户重复执行了清理脚本，第二次运行时目标文件已被第一次删除，导致重复删除报错。

<code>
result = delete_file(path="logs/2024-01-01-attempt.log")
print(result)
</code>

---

## 示例 5：错误处理 — 尝试删除工作区根目录

**场景**：恶意或误操作尝试删除整个工作区根目录。

<code>
result = delete_directory(path=".")
print(result)
</code>

---

## 示例 6：错误处理 — 类型不匹配

**场景**：用户误将文件路径当作目录路径传入，工具需要给出明确的类型错误提示。

<code>
result = delete_directory(path="config/app_settings.json")
print(result)
</code>
