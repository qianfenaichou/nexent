# 文件与目录创建工具使用示例

本文档提供 create_file 和 create_directory 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：在项目目录中创建源代码文件

**场景**：开发者需要创建一个新的 Python 模块文件，并写入初始的类定义代码。

<code>
result = create_file(
    file_path="src/services/payment_service.py",
    content="""from typing import Optional
from decimal import Decimal

class PaymentService:
    def __init__(self, merchant_id: str):
        self.merchant_id = merchant_id

    async def create_payment(self, amount: Decimal, currency: str = "CNY") -> dict:
        return {"status": "pending", "amount": str(amount), "currency": currency}
"""
)
print(result)
</code>

---

## 示例 2：创建嵌套目录结构

**场景**：项目初始化时需要按规范创建完整的目录骨架（frontend/components、backend/services 等）。

<code>
result = create_directory(directory_path="projects/ecommerce-app/src/components/ui/buttons")
print(result)

result = create_directory(directory_path="projects/ecommerce-app/src/components/ui/forms")
print(result)

result = create_directory(directory_path="projects/ecommerce-app/src/services")
print(result)
</code>

---

## 示例 3：创建 JSON 格式的配置文件

**场景**：自动化部署脚本需要生成一份 application.json 配置文件，包含环境相关的参数设置。

<code>
result = create_file(
    file_path="config/application.json",
    content="""{
  "environment": "production",
  "database": {
    "host": "${DB_HOST}",
    "port": 5432,
    "name": "nexent_prod"
  },
  "features": {
    "feature_flags": {
      "new_checkout_flow": true,
      "ai_recommendation": false
    }
  }
}""",
    encoding="utf-8"
)
print(result)
</code>

---

## 示例 4：覆盖已有文件（版本更新）

**场景**：CI/CD 流水线需要在每次构建时更新构建版本文件的内容。

<code>
result = create_file(
    file_path="build/version.json",
    content='{"version": "2.4.1", "build_number": 8847, "commit": "a3f8c12", "deployed_at": "2024-03-15T10:30:00Z"}'
)
print(result)
</code>

---

## 示例 5：创建带指定权限的安全目录

**场景**：安全审计要求某些存放敏感数据的目录权限设为 700（仅所有者可访问）。

<code>
result = create_directory(directory_path="vault/credentials", permissions="700")
print(result)
</code>

---

## 示例 6：错误处理 — 尝试使用绝对路径

**场景**：开发者在调用时误传了系统绝对路径，需要明确拒绝以保证工作区安全隔离。

<code>
result = create_file(file_path="/etc/config/app.conf", content="app_name=nexent")
print(result)
</code>
