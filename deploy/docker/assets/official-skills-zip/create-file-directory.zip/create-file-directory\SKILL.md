---
name: create-file-directory
allowed-tools:
  - create_file
  - create_directory
description: |
  在指定路径创建文件或目录。路径应为工作区相对路径（例如 'documents/file.txt'）。出于安全考虑，不允许使用绝对路径。
tags:
  - file
  - directory
  - explorer
---

# 文件与目录创建工具

在工作区内指定路径创建文件或目录。

## 可用工具

create_file - 创建文件并写入内容

create_directory - 创建目录

## create_file参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| file_path | string | 是 | - | 要创建文件的相对路径 |
| content | string | 否 | "" | 要写入文件的内容 |
| encoding | string | 否 | utf-8 | 文件编码 |

## create_directory参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| directory_path | string | 是 | - | 要创建目录的相对路径 |
| permissions | string | 否 | "755" | 八进制格式的目录权限 |

## 使用方式

<code>
result = create_file(file_path="documents/new.txt", content="Hello World")
print(result)
</code>

<code>
result = create_directory(directory_path="documents/new_folder", permissions="755")
print(result)
</code>

## 返回值

create_file 返回：
- `status`: "success"
- `file_path`: 相对路径
- `content_length`: 写入内容的长度
- `file_size_bytes`: 实际文件大小

create_directory 返回：
- `status`: "success"
- `directory_path`: 相对路径
- `permissions`: 应用的权限
- `already_existed`: 是否已存在

## 备注

- 自动为文件创建父目录
- 会覆盖已存在的文件
- 已存在的目录操作成功不会报错
- 安全限制：仅允许工作区相对路径

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />
