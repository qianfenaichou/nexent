#!/bin/bash
set -e

echo "📦 Bundling React app to single HTML artifact..."

OUTPUT_ROOT="$(pwd)"
PROJECT_DIR="${1:-.}"
OUTPUT_NAME="${2:-bundle.html}"

case "$PROJECT_DIR" in
  /*|*..*)
    echo "❌ Error: project directory must be a safe relative path."
    exit 1
    ;;
esac

cd -- "$PROJECT_DIR"

# Check if we're in a project directory
if [ ! -f "package.json" ]; then
  echo "❌ Error: No package.json found. Run this script from your project root."
  exit 1
fi

# Check if index.html exists
if [ ! -f "index.html" ]; then
  echo "❌ Error: No index.html found in project root."
  echo "   This script requires an index.html entry point."
  exit 1
fi

# Install bundling dependencies
echo "📦 Installing bundling dependencies..."
pnpm add -D parcel @parcel/config-default parcel-resolver-tspaths html-inline

# Create Parcel config with tspaths resolver
if [ ! -f ".parcelrc" ]; then
  echo "🔧 Creating Parcel configuration with path alias support..."
  cat > .parcelrc << 'EOF'
{
  "extends": "@parcel/config-default",
  "resolvers": ["parcel-resolver-tspaths", "..."]
}
EOF
fi

# Clean previous build
echo "🧹 Cleaning previous build..."
rm -rf dist bundle.html

# Build with Parcel
echo "🔨 Building with Parcel..."
pnpm exec parcel build index.html --dist-dir dist --no-source-maps

# Inline everything into single HTML
echo "🎯 Inlining all assets into single HTML file..."
pnpm exec html-inline dist/index.html > bundle.html

if [ "$PROJECT_DIR" != "." ] || [ "$OUTPUT_NAME" != "bundle.html" ]; then
  cp bundle.html "$OUTPUT_ROOT/$OUTPUT_NAME"
fi

# Get file size
FILE_SIZE=$(du -h bundle.html | cut -f1)

echo ""
echo "✅ Bundle complete!"
echo "📄 Output: $OUTPUT_NAME ($FILE_SIZE)"
echo ""
echo "You can now use this single HTML file as an artifact in Claude conversations."
echo "To test locally: open bundle.html in your browser"
