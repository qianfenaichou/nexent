# 分析文本文件工具使用示例

本文档提供 analyze_text_file 的实际应用案例，覆盖主要参数组合场景。

---

## 示例 1：提取合同关键条款

**场景**：法务助理收到一份 PDF 合同，需要快速提取甲方乙方名称、合同金额、付款方式和违约金条款。

<code>
results = analyze_text_file(file_url_list=["s3://contracts/supplier-2024-q1.pdf"], query="请从这份合同中提取以下信息：1. 甲方和乙方全称；2. 合同总金额及货币单位；3. 付款方式和付款周期；4. 违约金条款的具体规定。如果某项无法识别请标注未知。")
for result in results:
    print(result)
</code>

---

## 示例 2：批量分析多份竞品调研文档

**场景**：产品经理需要同时分析三份来自不同部门的竞品分析报告，生成一份综合对比摘要。

<code>
results = analyze_text_file(file_url_list=[
    "s3://research/competitor-a-analysis.pdf",
    "s3://research/competitor-b-analysis.pdf",
    "s3://research/competitor-c-analysis.pdf"
], query="请分别总结三份竞品分析报告的核心结论，最后用一段话综合对比三者各自的优势和劣势。")
for result in results:
    print(result)
</code>

---

## 示例 3：从用户手册生成操作步骤清单

**场景**：技术支持工程师需要将一份 50 页的设备用户手册转化为可执行的安装步骤清单。

<code>
results = analyze_text_file(file_url_list=["https://internal-docs.example.com/device-manual-v3.pdf"], query="请将这份用户手册中的安装和配置步骤提取出来，以编号列表的形式呈现，每一步描述控制在20字以内，只保留关键操作动作。")
for result in results:
    print(result)
</code>

---

## 示例 4：从日志文件诊断系统问题

**场景**：运维工程师发现某服务异常，需要从滚动日志中提取 ERROR 和 WARNING 级别的记录并归类。

<code>
results = analyze_text_file(file_url_list=["s3://logs/service-api-2024-03-15.log"], query="请分析这份日志文件：1. 统计 ERROR 和 WARNING 各自出现的次数；2. 列出出现频率最高的3种错误类型；3. 推测最可能的根因并给出排查建议。")
for result in results:
    print(result)
</code>

---

## 示例 5：分析代码仓库中的 README 文档

**场景**：新加入项目的开发人员需要快速了解一个陌生代码库的架构和本地启动方式。

<code>
results = analyze_text_file(file_url_list=["https://raw.githubusercontent.com/example/nexus-service/main/README.md"], query="请总结这份 README 的核心内容：1. 项目定位和主要功能；2. 技术栈和依赖要求；3. 本地开发环境的启动步骤；4. 关键的配置项说明。")
for result in results:
    print(result)
</code>

---

## 示例 6：错误处理 — 文件格式不支持文本提取

**场景**：用户上传了一个图片文件（JPG）但误用了文本分析工具，希望获得友好的错误提示。

<code>
results = analyze_text_file(file_url_list=["s3://user-uploads/photo.jpg"], query="请描述这个文件的内容")
for result in results:
    print(result)
</code>
