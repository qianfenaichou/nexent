---
name: analyze-text-file
allowed-tools:
  - analyze_text_file
description: |
  从文本文件中提取内容，并根据问题使用大语言模型进行分析。支持来自 S3 URL（s3://bucket/key 或 /bucket/key）、HTTP 和 HTTPS URL 的文件。
tags:
  - multimodal
  - text-extraction
---

# 分析文本文件工具

使用大语言模型来提取和分析文本文件内容。

## 可用方法

analyze_text_file

## 方法参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| file_url_list | array | 是 | - | 文件 URL 列表（S3、HTTP 或 HTTPS） |
| query | string | 是 | - | 用于指导分析的用户问题 |

## 支持的 URL 格式

- S3: `s3://bucket/key` 或 `/bucket/key`
- HTTP: `http://example.com/document.pdf`
- HTTPS: `https://example.com/document.pdf`

## 使用方式

<code>
results = analyze_text_file(file_url_list=["s3://bucket/docs/report.pdf", "https://example.com/notes.txt"], query="总结这些文档的要点")
for result in results:
    print(result)
</code>

## 返回值

返回字符串数组，每个文件按顺序返回一个分析结果：
- `results[0]`: 第一个文件的分析结果
- `results[1]`: 第二个文件的分析结果
- 以此类推

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| No text content extracted | 不支持的文件格式 | 验证文件是否为文本格式 |
| LLM analysis failed | 模型错误 | 检查 llm_model 配置 |
| File download failed | URL 无效或网络问题 | 验证文件 URL |

## 备注

- 每个文件按输入顺序返回一个结果
- 支持在单个调用中处理多个文件
- 使用外部数据处理服务进行文本提取
- 仅分析基于文本的文件（不包括图片）

## 示例参考

> **注意**：仅当默认 Usage 示例不能满足需求时，再加载参考示例文件。

<reference path="examples.md" />
