#!/usr/bin/env python3
"""Create a new blank Word document."""

import argparse
import json
import os
import sys
from pathlib import Path


# Default directory for generated files (same as other file creation tools)
_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def create_document(path: str, working_dir: str = None) -> dict:
    """Create a new blank Word document.

    Args:
        path: Output file name
        working_dir: Working directory (defaults to $NEXENT_WORKSPACE/outputs when available)
    """
    from docx import Document
    from docx.shared import Inches

    # Ensure .docx extension
    if not path.lower().endswith(".docx"):
        path += ".docx"

    # Use default directory if working_dir not specified
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    abs_path = os.path.abspath(os.path.join(working_dir, path))
    Path(abs_path).parent.mkdir(parents=True, exist_ok=True)

    # Create document with default margins
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path
    }


def main():
    parser = argparse.ArgumentParser(description="Create a new Word document")
    parser.add_argument("--path", "-p", required=True, help="Output file path")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = create_document(args.path, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
