#!/usr/bin/env python3
"""Update a specific table cell in a Word document."""

import argparse
import json
import os
import sys


_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def update_table_cell(path: str, table_index: int, row_index: int, col_index: int, text: str, working_dir: str = None) -> dict:
    """Update a specific table cell in an existing Word document."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    from docx import Document

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    doc = Document(abs_path)

    if table_index < 0 or table_index >= len(doc.tables):
        raise IndexError(f"Table index out of range: {table_index}")

    table = doc.tables[table_index]

    if row_index < 0 or row_index >= len(table.rows):
        raise IndexError(f"Row index out of range: {row_index}")
    if col_index < 0 or col_index >= len(table.rows[row_index].cells):
        raise IndexError(f"Column index out of range: {col_index}")

    table.rows[row_index].cells[col_index].text = text
    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "table_index": table_index,
        "row_index": row_index,
        "col_index": col_index
    }


def main():
    parser = argparse.ArgumentParser(description="Update a specific table cell in a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--table-index", type=int, required=True, help="Table index")
    parser.add_argument("--row-index", type=int, required=True, help="Row index")
    parser.add_argument("--col-index", type=int, required=True, help="Column index")
    parser.add_argument("--text", required=True, help="Cell text")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = update_table_cell(args.path, args.table_index, args.row_index, args.col_index, args.text, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
