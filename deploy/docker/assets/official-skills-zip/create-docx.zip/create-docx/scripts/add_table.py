#!/usr/bin/env python3
"""Add a table to a Word document."""

import argparse
import json
import os
import sys


# Default directory for generated files (same as other file creation tools)
_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def add_table(path: str, data: str, has_header: bool = True, working_dir: str = None) -> dict:
    """Add a table to an existing Word document."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    import json as json_lib

    from docx import Document

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    # Parse JSON data
    try:
        table_data = json_lib.loads(data)
    except json_lib.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON data: {e}")

    if not table_data or not isinstance(table_data, list):
        raise ValueError("Table data must be a non-empty list of rows")

    rows = len(table_data)
    cols = len(table_data[0]) if table_data[0] else 0

    if rows < 1 or cols < 1:
        raise ValueError("Table must have at least one row and one column")

    doc = Document(abs_path)

    # Create table
    table = doc.add_table(rows=rows, cols=cols)
    table.style = "Table Grid"

    # Fill data
    for i, row_data in enumerate(table_data):
        row = table.rows[i]
        for j, cell_data in enumerate(row_data):
            if j < cols:
                row.cells[j].text = str(cell_data)

    # Bold header row
    if has_header and rows > 0:
        header_row = table.rows[0]
        for cell in header_row.cells:
            for para in cell.paragraphs:
                for run in para.runs:
                    run.font.bold = True

    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "rows": rows,
        "columns": cols,
        "has_header": has_header
    }


def main():
    parser = argparse.ArgumentParser(description="Add a table to a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--data", "-d", required=True, help="Table data as JSON array")
    parser.add_argument("--has-header", action="store_true", default=True,
                        help="First row is header (default: true)")
    parser.add_argument("--no-header", dest="has_header", action="store_false",
                        help="First row is not header")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = add_table(args.path, args.data, args.has_header, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
