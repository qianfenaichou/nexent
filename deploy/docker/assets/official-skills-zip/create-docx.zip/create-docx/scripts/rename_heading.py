#!/usr/bin/env python3
"""Rename an existing heading in a Word document."""

import argparse
import json
import os
import sys


_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def rename_heading(path: str, old_text: str, new_text: str, working_dir: str = None) -> dict:
    """Rename matching heading text in an existing Word document."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    from docx import Document

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    doc = Document(abs_path)
    renamed_count = 0

    for paragraph in doc.paragraphs:
        style_name = getattr(paragraph.style, "name", "")
        if style_name.startswith("Heading") and old_text in paragraph.text:
            paragraph.text = paragraph.text.replace(old_text, new_text)
            renamed_count += 1

    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "renamed_count": renamed_count
    }


def main():
    parser = argparse.ArgumentParser(description="Rename an existing heading in a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--old-text", required=True, help="Current heading text")
    parser.add_argument("--new-text", required=True, help="New heading text")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = rename_heading(args.path, args.old_text, args.new_text, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
