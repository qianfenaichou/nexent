#!/usr/bin/env python3
"""Add a heading to a Word document."""

import argparse
import json
import os
import sys


# Default directory for generated files (same as other file creation tools)
_WORKSPACE_DIR = os.environ.get("NEXENT_WORKSPACE")
DEFAULT_OUTPUT_DIR = (
    os.path.join(_WORKSPACE_DIR, "outputs")
    if _WORKSPACE_DIR
    else "/mnt/nexent"
)


def add_heading(path: str, text: str, level: int = 1, working_dir: str = None) -> dict:
    """Add a heading to an existing Word document."""
    if working_dir is None:
        working_dir = DEFAULT_OUTPUT_DIR

    from docx import Document

    abs_path = os.path.abspath(os.path.join(working_dir, path))

    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Document not found: {abs_path}")

    # Clamp level to valid range
    level = max(1, min(9, level))

    doc = Document(abs_path)
    doc.add_heading(text, level=level)
    doc.save(abs_path)

    return {
        "status": "success",
        "file_path": path,
        "absolute_path": abs_path,
        "heading_text": text,
        "heading_level": level
    }


def main():
    parser = argparse.ArgumentParser(description="Add a heading to a Word document")
    parser.add_argument("--path", "-p", required=True, help="Document path")
    parser.add_argument("--text", "-t", required=True, help="Heading text")
    parser.add_argument("--level", "-l", type=int, default=1, help="Heading level (1-9)")
    parser.add_argument("--working-dir", "-w", default=None,
                        help=f"Working directory (defaults to {DEFAULT_OUTPUT_DIR})")

    args = parser.parse_args()

    try:
        result = add_heading(args.path, args.text, args.level, args.working_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    except Exception as e:
        error_result = {"status": "error", "message": str(e)}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
